/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.racetracker

import com.example.racetracker.ui.RaceParticipant
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class RaceParticipantTest {

    private val raceParticipant = RaceParticipant(
        name = "Test",
        maxProgress = 100,
        progressDelayMillis = 500L,
        initialProgress = 0,
        progressIncrement = 1
    )

    // ==================== SUCCESS PATH TESTS (2) ====================

    @Test
    fun raceParticipant_RaceStarted_ProgressUpdated() = runTest {
        val expectedProgress = 1
        launch { raceParticipant.run() }
        advanceTimeBy(raceParticipant.progressDelayMillis)
        runCurrent()
        assertEquals(expectedProgress, raceParticipant.currentProgress)
    }

    @Test
    fun raceParticipant_RaceFinished_ProgressUpdated() = runTest {
        launch { raceParticipant.run() }
        advanceTimeBy(raceParticipant.maxProgress * raceParticipant.progressDelayMillis)
        runCurrent()
        assertEquals(FINAL_PROGRESS, raceParticipant.currentProgress)
    }

    // ==================== BOUNDARY CASE TESTS (2) ====================

    @Test
    fun raceParticipant_Initialization_ProgressAtStart() = runTest {
        assertEquals(INITIAL_PROGRESS, raceParticipant.currentProgress)
    }

    @Test
    fun raceParticipant_RaceAlmostFinished_ProgressUpdated() = runTest {
        val almostFinished = raceParticipant.maxProgress - 1
        launch { raceParticipant.run() }
        advanceTimeBy(almostFinished * raceParticipant.progressDelayMillis)
        runCurrent()
        assertEquals(almostFinished, raceParticipant.currentProgress)
    }

    // ==================== ERROR PATH TESTS (2) ====================

    @Test
    fun raceParticipant_ProgressDoesNotExceedMax() = runTest {
        launch { raceParticipant.run() }
        // Advance time beyond what's needed to finish the race
        advanceTimeBy((raceParticipant.maxProgress + 10) * raceParticipant.progressDelayMillis)
        runCurrent()
        assertEquals(FINAL_PROGRESS, raceParticipant.currentProgress)
    }

    @Test
    fun raceParticipant_PartialTimeAdvancement_ProgressDoesNotUpdate() = runTest {
        launch { raceParticipant.run() }
        // Advance less time than required for one increment
        advanceTimeBy(raceParticipant.progressDelayMillis / 2)
        runCurrent()
        assertEquals(INITIAL_PROGRESS, raceParticipant.currentProgress)
    }

    // ==================== COMPANION OBJECT WITH CONSTANTS ====================

    companion object {
        private const val INITIAL_PROGRESS = 0
        private const val FINAL_PROGRESS = 100
    }
}